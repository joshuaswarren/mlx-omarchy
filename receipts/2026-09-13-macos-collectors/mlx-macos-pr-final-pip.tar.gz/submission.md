## mlx-omarchy hardware report

Machine: Mac14,2 / Apple M2 (macOS 26.6.2 (25G83), Darwin 25.6.0)
Native MLX: 0.32.1, Metal available: True
Native macOS reference only. This does not prove Linux support, ANE execution, or performance parity.
Source commit: e1ca0b61f436093155f2e8f55bc962c7396ef9c6
Correctness: 6/6 probe ops pass
Not available on this machine: profile
Redaction applied before writing: {"home_path": 14} (names, paths, IPs, MACs, serials, credentials; no upload code)

Members with SHA-256 (see attached archive for full contents):

```
222e62b3ba1cc4935027ad9349a7d036b3fd0ed7c8e10778772cc9791a8d5160  benchmark.json (6103 B)
ec1b1f4bbea4398d7ee196767da27c5d1c7d301e2c2ff1e982a3c29b5602bb36  correctness.json (6444 B)
1f707bd0665265edb39df14e37fbb8a4757ae4db932ce7f3dc30f44f6667a4d9  environment.json (344 B)
cb405dc94842e0d0bdcb301f1ab1930735b643177b37b82b161be0cc76a5534a  profile.json (94 B)
a32039cf3f6e9aa292d64202589a883df68f350da008990b1bbf751a5193e47a  quick.json (2697 B)
451958d5e37439d97728086a52c4779e11425a8690a2be25203271ebcf6c5cb2  thermal.json (98 B)
```

<details><summary>quick report JSON</summary>

```json
{
  "_redaction": {},
  "ane": {
    "available": false,
    "error": "not applicable to native macOS MLX"
  },
  "host": {
    "arch": "arm64",
    "available": true,
    "chip": "Apple M2",
    "cpu": {
      "hotplug_control": null,
      "present": 8
    },
    "cpu_online": 8,
    "gpu": {
      "chipset": "Apple M2",
      "gpu_cores": "8",
      "metal": "Metal 4"
    },
    "kernel_release": "25.6.0",
    "memory_total_mib": 24576,
    "model": "Mac14,2",
    "os": "macOS 26.6.2 (25G83)",
    "system": "Darwin"
  },
  "mesa": {
    "available": false,
    "error": "not applicable to native macOS MLX"
  },
  "mesa_package": {
    "available": false,
    "error": "not applicable to native macOS MLX"
  },
  "mlx": {
    "available": true,
    "capabilities": null,
    "default_device": "Device(gpu, 0)",
    "distributions": {
      "mlx": "0.32.1"
    },
    "import_error": null,
    "info": null,
    "info_tool": null,
    "metal_available": true,
    "mlx_version": "0.32.1",
    "probe": {
      "argv": [
        "/private/tmp/mlx-macos-pip-test/bin/python",
        "-c",
        "\nimport json\nout = {\"distributions\": {}, \"import_ok\": False, \"import_error\": None,\n       \"info_tool\": None, \"default_device\": None, \"mlx_version\": None}\nimport importlib.metadata\nfor dist in (\"mlx-omarchy\", \"mlx\"):\n    try:\n        out[\"distributions\"][dist] = importlib.metadata.version(dist)\n    except Exception:\n        pass\nimport pathlib\ntry:\n    import mlx.core as mx\n    out[\"import_ok\"] = True\n    import platform\n    if platform.system() == \"Darwin\":\n        out[\"metal_available\"] = mx.metal.is_available()\n        if out[\"metal_available\"]:\n            mx.set_default_device(mx.gpu)\n    out[\"default_device\"] = str(mx.default_device())\n    out[\"mlx_version\"] = getattr(mx, \"__version__\", None)\n    # mlx is a namespace package (mlx.__file__ is None); anchor on the\n    # extension module, which lives beside the shipped bin/ directory.\n    cand = pathlib.Path(mx.__file__).resolve().parent / \"bin\" / \"mlx-omarchy-info\"\n    if cand.exists():\n        out[\"info_tool\"] = str(cand)\nexcept Exception as exc:\n    out[\"import_error\"] = f\"{type(exc).__name__}: {exc}\"\nprint(json.dumps(out))\n"
      ],
      "available": true,
      "error": null,
      "exit_code": 0,
      "label": "mlx import probe",
      "stderr": "",
      "stdout": "{\"distributions\": {\"mlx\": \"0.32.1\"}, \"import_ok\": true, \"import_error\": null, \"info_tool\": null, \"default_device\": \"Device(gpu, 0)\", \"mlx_version\": \"0.32.1\", \"metal_available\": true}"
    }
  },
  "report": "mlx-omarchy-quick",
  "schema_version": 1
}
```

</details>
